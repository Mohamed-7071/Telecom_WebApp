﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace safeprojectname
{
    public partial class Cashback_Transactions1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            string connStr = WebConfigurationManager.ConnectionStrings["Milestone2implementation-Final"].ToString();
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                //String viewcommand = "select p.*, v.voucherID,v.value from Physical_shop p inner join Voucher v on p.shopID = v.shopid";
                String viewcommand = "select walletID,count(*)as 'count of transactions' from Cashback\r\ngroup by walletID\r\n";
                using (SqlCommand allCustomerAccounts = new SqlCommand(viewcommand, conn))
                {
                    conn.Open();

                    using (SqlDataAdapter sda = new SqlDataAdapter(allCustomerAccounts))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                }
            }
        }

    }
}