﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace safeprojectname
{
    public partial class Payment_Transactions : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["Milestone2implementation-Final"].ToString();
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                String viewcommand = "select * from Payment p";
                using (SqlCommand allresolvedtickets = new SqlCommand(viewcommand, conn))
                {
                    conn.Open();

                    using (SqlDataAdapter sdaa = new SqlDataAdapter(allresolvedtickets))
                    {
                        DataTable dt = new DataTable();
                        sdaa.Fill(dt);

                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                }
            }

        }
    }
}