﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace safeprojectname
{
    public partial class buttons : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Response.Redirect("customer_account.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Response.Redirect("physical stores.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Response.Redirect("resolved tickets.aspx");
        }

        protected void Button5_Click(object sender, EventArgs e)
        {
            Response.Redirect("sub accounts.aspx");
        }

        protected void Button4_Click(object sender, EventArgs e)
        {
            Response.Redirect("wallets.aspx");
        }

        protected void Button6_Click(object sender, EventArgs e)
        {

        }

        protected void Button8_Click(object sender, EventArgs e)
        {

        }

        protected void Button7_Click(object sender, EventArgs e)
        {

        }

        protected void Button9_Click(object sender, EventArgs e)
        {
            Response.Redirect("subscribed to the input plan id.aspx");
        }

        protected void Button10_Click(object sender, EventArgs e)
        {
            Response.Redirect("eshop.aspx");
        }

        protected void Button11_Click(object sender, EventArgs e)
        {
            Response.Redirect("Payment Transactions.aspx");
        }

        protected void Button12_Click(object sender, EventArgs e)
        {
            Response.Redirect("Cashback Transactions.aspx");
        }

        protected void Button15_Click(object sender, EventArgs e)
        {

        }

        protected void Button13_Click(object sender, EventArgs e)
        {

        }

        protected void Button16_Click(object sender, EventArgs e)
        {

        }

        protected void Button14_Click(object sender, EventArgs e)
        {

        }

        protected void Button17_Click(object sender, EventArgs e)
        {

        }
    }
}