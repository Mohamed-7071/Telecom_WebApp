﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace safeprojectname
{
    public partial class customer_account : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["Milestone2implementation-Final"].ToString();
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                String viewcommand = "SELECT p.*,a.mobileNo,a.account_type,a.status,a.start_date,a.balance,a.points from customer_profile p\r\ninner join customer_account a \r\non p.nationalID = a.nationalID\r\nwhere a.status = 'active'";

                using (SqlCommand allCustomerAccounts = new SqlCommand(viewcommand, conn))
                {
                    conn.Open();

                    using (SqlDataAdapter sda = new SqlDataAdapter(allCustomerAccounts))
                    {
                        DataTable dt = new DataTable();
                        sda.Fill(dt);

                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                }
            }


            //SqlCommand ;
            //allCustomerAccounts.CommandType = CommandType.;



            //try
            //{

            //    conn.Open()
            //    SqlDataReader rdr = allCustomerAccounts.ExecuteReader(CommandBehavior.CloseConnection);
            //    while (rdr.Read())
            //    {
            //        string account = rdr.GetString(rdr.GetOrdinal("name"));
            //            Label name = new Label();
            //        String courseName = ;
            //        name.Text = courseName;
            //        Form1.Controls.Add(name);

            //    }
            //    rdr.Close();
            //}
            //catch (Exception ex)
            //{
            //    // Handle potential errors
            //    Response.Write("An error occurred: " + ex.Message);
            //}
            //finally
            //{
            //    // Ensure the connection is closed
            //    if (conn.State == ConnectionState.Open)
            //    {
            //        conn.Close();
            //    }
            //}
        }
    }   
}