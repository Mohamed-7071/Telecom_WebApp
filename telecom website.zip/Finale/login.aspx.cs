﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace safeprojectname
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Optional: Add logic here for Page Load if needed.
        }

        protected void Login(object sender, EventArgs e)
        {

            string username = mobileno_ID.Text.Trim();
            string password = password_ID.Text.Trim();

            try
            {

                if (username.Equals("ADMIN", StringComparison.OrdinalIgnoreCase) && password.Equals("ADMIN", StringComparison.OrdinalIgnoreCase))
                {

                    Response.Redirect("buttons.aspx");
                }
                else
                {
                    Response.Write("<script>alert('Invalid login credentials. Please try again.');</script>");
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('An error occurred: " + ex.Message + "');</script>");
            }
        }

    }
}