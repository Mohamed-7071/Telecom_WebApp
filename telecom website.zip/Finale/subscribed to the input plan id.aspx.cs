﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Reflection.Emit;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace safeprojectname
{
    public partial class subscribed_to_the_input_plan_id : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Connection string from Web.config
            string connStr = WebConfigurationManager.ConnectionStrings["Milestone2implementation-Final"].ToString();

            // Get input values from TextBoxes
            string subscriptionDate = Request.Form["TextBox1"]; // Retrieve the date input
            string planID = Request.Form["TextBox2"]; // Retrieve the plan ID input

            // Query to call the SQL function
            string query = "SELECT * FROM dbo.Account_Plan_date(@sub_date, @plan_id)";

            //try
            //{
            //foreach (string key in Request.Form.AllKeys)
            //{
            //    Label1.Text = Label1.Text + " " + Request.Form[key];
            //}
            

            //using (SqlConnection conn = new SqlConnection(connStr))
            //{
            //    using (SqlCommand cmd = new SqlCommand(query, conn))
            //    {
            //        // Add parameters for the SQL function
            //        cmd.Parameters.AddWithValue("@sub_date", subscriptionDate);
            //        cmd.Parameters.AddWithValue("@plan_id", planID);

            //        // Open the database connection
            //        conn.Open();

            //        // Execute the query and read the results

            //        using (SqlDataAdapter sda = new SqlDataAdapter(cmd))
            //        {


            //            DataTable dt = new DataTable();
            //            sda.Fill(dt);

            //            GridView1.DataSource = dt;
            //            GridView1.DataBind();
            //        }
            //using (SqlDataReader reader = cmd.ExecuteReader())
            //{
            //    if (reader.HasRows)
            //    {
            //        while (reader.Read())
            //        {
            //            // Retrieve columns from the result
            //            string mobileNo = reader["mobileNo"].ToString();
            //            string retrievedPlanID = reader["planID"].ToString();
            //            string planName = reader["name"].ToString();

            //            // Display the result (example: adding to a label or console output)
            //            Response.Write($"Mobile: {mobileNo}, Plan ID: {retrievedPlanID}, Plan Name: {planName}<br>");
            //        }
            //    }
            //else
            //{
            //    // No data found
            //    Response.Write("<script>alert('No records found matching the criteria.');</script>");
            //}
            //    }
            //}
        }

        protected void ButtonSubmit_Click(object sender, EventArgs e)
        {

            string connStr = WebConfigurationManager.ConnectionStrings["Milestone2implementation-Final"].ToString();


            String s = TextBoxPlanId.Text.ToString();
            DateTime subscriptionDate = new DateTime();
            subscriptionDate = DateTime.ParseExact(s, "yyyy-MM-dd", null);

            string planID = TextBoxDate.Text;
            string query = "SELECT * FROM dbo.Account_Plan_date(@sub_date , @plan_id)";



            using (SqlConnection conn = new SqlConnection(connStr))
            {
                using (SqlCommand allresolvedtickets = new SqlCommand(query, conn))
                {
                    allresolvedtickets.Parameters.AddWithValue("@sub_date", subscriptionDate);
                    allresolvedtickets.Parameters.AddWithValue("@plan_id", planID);
                    conn.Open();

                    using (SqlDataAdapter sdaa = new SqlDataAdapter(allresolvedtickets))
                    {
                        DataTable dt = new DataTable();
                        sdaa.Fill(dt);

                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                }
            }




        }
        //}
        //catch (Exception ex)
        //{
        //    // Handle any errors
        //    Response.Write("<script>alert('An error occurred: " + ex.Message + "');</script>");
        //}


    }
}