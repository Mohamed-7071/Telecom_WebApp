﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace safeprojectname
{
    public partial class wallet1 : System.Web.UI.Page
    {
        string conn = ConfigurationManager.ConnectionStrings["Milestone2implementation-Final"].ConnectionString.ToString();
        SqlConnection cn;
        SqlCommand cmd;
        SqlDataReader dr;

        protected void Page_Load(object sender, EventArgs e)
        {
            string connStr = WebConfigurationManager.ConnectionStrings["Milestone2implementation-Final"].ToString();
            using (SqlConnection conn = new SqlConnection(connStr))
            {
                String viewcommand = "select * from CustomerWallet";
                using (SqlCommand allresolvedtickets = new SqlCommand(viewcommand, conn))
                {
                    conn.Open();

                    using (SqlDataAdapter sdaa = new SqlDataAdapter(allresolvedtickets))
                    {
                        DataTable dt = new DataTable();
                        sdaa.Fill(dt);

                        GridView1.DataSource = dt;
                        GridView1.DataBind();
                    }
                }

            }
        }
    }
}